﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace Biblioteka_AS
{
    public partial class Knjiga : Form
    {

        public List<KnjigaClass> CreateBookListXml()
        {
            List<KnjigaClass> knjigaList = new List<KnjigaClass>();
            XDocument CreateBookListXml()
            {

                var dokumentXmlKnjige = new XDocument(new XElement("lista_knjiga",
                    from KnjigaClass in knjigaList
                    select new XElement("Klijent",
                        new XAttribute("Autor", KnjigaClass.Ime),
                        new XAttribute("Naziv", KnjigaClass.Naziv),
                        new XElement("ISBN", KnjigaClass.Isbn),
                        new XAttribute("Izdavac", KnjigaClass.Izdavac),
                        new XAttribute("Naziv", KnjigaClass.Godina)
                        )));
                return dokumentXmlKnjige;
            }
        }

        public Knjiga()
        {
            InitializeComponent();
        }

        private void Knjiga_Load(object sender, EventArgs e)
        {

        }

        private void autorimetxt_TextChanged(object sender, EventArgs e)
        {

        }


        public void unesiknjigubtn_Click(object sender, EventArgs e)
        {
            

        }

        private void odustaniknjigabtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnknjigaclr_Click(object sender, EventArgs e)
        {
            autorimetxt.Clear();
            nazivknjigetxt.Clear();
            isbntxt.Clear();
            izdavactxt.Clear();
            godinatxt.Clear();
        }

        private void nazivknjigetxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
